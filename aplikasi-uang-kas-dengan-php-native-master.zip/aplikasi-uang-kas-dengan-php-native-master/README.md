# aplikasi-uang-kas-dengan-php-native
Aplikasi Sederhana untuk mengelola uang kas sekaligus pengeluarannya. 
Aplikasi ini hanya dapat menghandle satu kelas saja.
Meskipun begitu, tapi aplikasi ini sangat praktis dan tetap optimal dengan bisa menghandle uang kas dalam beberapa tahun serta menyediakan fitur-fitur yang sangat dibutuhkan seperti: riwayat pembayaran dan pengeluaran, laporan hasil perbulan dan lain-lain. 

Cara memasangnya:
1. Download file ini
2. Ekstrak pada htdocs/
3. Buka phpmyadmin
4. Buat database dengan nama: uang_kas
5. Import file uang_kas.sql pada folder yang di ekstrak tadi
6. Buka localhost/uang_kas
7. Selesai

Akun:

Administrator:

❥ Username: andri123

❥ Password: 123456


Bendahara:

❥ Username: andre123

❥ Password: 123456


Guru:

❥ Username: annisa321

❥ Password: 123456


Fitur:
- Hak akses
- Mengelola Uang Kas Perbulan
- Riwayat Pembayaran
- Mengelola Pengeluaran
- Riwayat Pengeluaran
- Ganti Password
- Dan Lainnya
